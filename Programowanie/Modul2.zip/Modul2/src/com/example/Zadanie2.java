package com.example;

public class Zadanie2 {
    public static void main() {

        double Radius = 7.5;
        //double Perimeter = 47.12388980384689;
        //double Area = 176.71458676442586;
        System.out.println("For Radius = 7.5:");
        double Perimeter = 2 * Math.PI * Radius;
        System.out.println("Perimeter = " + Perimeter);
        double Area = Math.PI * Radius;
        System.out.println("Area = " + Area);




    }
}
