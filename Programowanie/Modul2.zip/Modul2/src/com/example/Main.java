package com.example;

import java.util.Scanner;

public class Main {

    public static void main(String[] args) {

        /*Scanner scanner = new Scanner(System.in);

        System.out.print("Enter first number: ");
        int number1 = scanner.nextInt();
        System.out.print("Enter second number: ");
        int number2 = scanner.nextInt();
        int multiplication = number1 * number2;

        System.out.println(number1 + " * " + number2 + " equals " + multiplication);


        System.out.print("Enter radius: ");
        double radius = scanner.nextDouble();
        double perimeter = 2 * Math.PI * radius;
        double area = Math.PI * Math.pow(radius, 2.0);

        System.out.println("For radius " + radius);
        System.out.println("Perimeter is " + perimeter);
        System.out.println("Area is " + area);

        System.out.println();*/

        Zadanie1.main();
        Zadanie2.main();
    }

}
