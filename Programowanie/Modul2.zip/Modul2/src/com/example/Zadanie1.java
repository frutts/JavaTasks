package com.example;

public class Zadanie1 {
    public static void main() {
        int a = 25;
        int b = 5;
        int c = a*b; //=125
        System.out.println(c);


    }
}
