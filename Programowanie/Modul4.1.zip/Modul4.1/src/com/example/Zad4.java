package com.example;


public class Zad4 {
    public static void main(String[] args){

        String OriginalString = "PHP Exercises an d Python Exercises";

        System.out.println();
        System.out.println("Specified sequence of char values: and ");
        System.out.println();
        CharSequence x = "and";
        System.out.println(OriginalString.contains(x));
    }
}
