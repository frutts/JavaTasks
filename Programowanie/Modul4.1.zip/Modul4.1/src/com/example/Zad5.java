package com.example;

public class Zad5 {
    public static void main(String[] args) {

        String s1 = "Stephen Edwin King";
        String s2 = "Walter Winchell";
        String s3 = "Mike Royko";

        System.out.println("\"Stephen Edwin King\" equals \"Walter Winchell\"? " + s1.equals(s2));

        System.out.println("\"Stephen Edwin King\" equals \"Mike Royko\"? " + s1.equals(s3));
    }
}
