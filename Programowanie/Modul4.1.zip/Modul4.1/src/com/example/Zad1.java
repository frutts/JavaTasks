package com.example;

public class Zad1 {
    public static void main(String[] args) {


        String orginalString = "Java Exercises! ";


        System.out.println("\nCharacter at position 0 is: " + orginalString.charAt(0));
        System.out.println("Character at position 10 is: "+ orginalString.charAt(10));




    }
}
