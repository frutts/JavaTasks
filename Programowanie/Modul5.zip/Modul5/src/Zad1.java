public class Zad1 {
    public static void main(String[] args) {

    for(int i=1; i<21; i++) {
        if (i == 13) {
            System.out.println(i + " To jest Twoja szczęśliwa liczba! ");
        }else{
            System.out.println(i);

        }
    }



}
}
