public class Zadanie {
}
